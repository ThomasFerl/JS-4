mono-complete package should be installed to run Yabe on Linux,
then launch Yabe with the following command

	mono ./Yabe.exe