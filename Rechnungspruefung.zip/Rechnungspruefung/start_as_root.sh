clear
sudo /home/tferl/.nvm/versions/node/v18.14.1/bin/node backend.js


